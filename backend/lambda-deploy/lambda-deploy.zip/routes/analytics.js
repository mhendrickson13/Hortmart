"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const db_js_1 = require("../db.js");
const auth_js_1 = require("../middleware/auth.js");
const router = (0, express_1.Router)();
// GET /analytics - Dashboard analytics (Admin only)
router.get('/', auth_js_1.authenticate, auth_js_1.requireAdmin, async (req, res) => {
    try {
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        const thirtyDaysStr = thirtyDaysAgo.toISOString().replace('T', ' ').replace('Z', '');
        // Overview counts
        const [usersRow, coursesRow, enrollmentsRow] = await Promise.all([
            (0, db_js_1.queryOne)('SELECT COUNT(*) as cnt FROM users'),
            (0, db_js_1.queryOne)('SELECT COUNT(*) as cnt FROM courses'),
            (0, db_js_1.queryOne)('SELECT COUNT(*) as cnt FROM enrollments'),
        ]);
        const totalUsers = Number(usersRow?.cnt ?? 0);
        const totalCourses = Number(coursesRow?.cnt ?? 0);
        const totalEnrollments = Number(enrollmentsRow?.cnt ?? 0);
        // Total revenue
        const revenueRow = await (0, db_js_1.queryOne)(`SELECT SUM(c.price * sub.cnt) as revenue
       FROM courses c JOIN (SELECT courseId, COUNT(*) as cnt FROM enrollments GROUP BY courseId) sub ON c.id = sub.courseId`);
        const totalRevenue = Number(revenueRow?.revenue ?? 0);
        // Active users (with progress in last 30 days)
        const activeRow = await (0, db_js_1.queryOne)(`SELECT COUNT(DISTINCT en.userId) as cnt
       FROM lesson_progress lp JOIN enrollments en ON lp.enrollmentId = en.id
       WHERE lp.lastWatchedAt >= ?`, [thirtyDaysStr]);
        const activeUsers = Number(activeRow?.cnt ?? 0);
        // Completion rate
        const enrollmentsForCompletion = await (0, db_js_1.query)(`SELECT en.id as enrollmentId, en.courseId FROM enrollments en`);
        let completedCount = 0;
        if (enrollmentsForCompletion.length > 0) {
            const courseIds = [...new Set(enrollmentsForCompletion.map(e => e.courseId))];
            const cp = (0, db_js_1.inPlaceholders)(courseIds);
            const lessonCounts = await (0, db_js_1.query)(`SELECT m.courseId, COUNT(l.id) as cnt FROM modules m JOIN lessons l ON l.moduleId = m.id WHERE m.courseId IN (${cp}) GROUP BY m.courseId`, courseIds);
            const totalLessonsMap = new Map(lessonCounts.map(r => [r.courseId, Number(r.cnt)]));
            const eIds = enrollmentsForCompletion.map(e => e.enrollmentId);
            const ep = (0, db_js_1.inPlaceholders)(eIds);
            const completedLessonCounts = await (0, db_js_1.query)(`SELECT enrollmentId, COUNT(*) as cnt FROM lesson_progress WHERE enrollmentId IN (${ep}) AND completedAt IS NOT NULL GROUP BY enrollmentId`, eIds);
            const completedMap = new Map(completedLessonCounts.map(r => [r.enrollmentId, Number(r.cnt)]));
            for (const enr of enrollmentsForCompletion) {
                const tl = totalLessonsMap.get(enr.courseId) ?? 0;
                const cl = completedMap.get(enr.enrollmentId) ?? 0;
                if (tl > 0 && cl >= tl)
                    completedCount++;
            }
        }
        const completionRate = totalEnrollments > 0 ? (completedCount / totalEnrollments) * 100 : 0;
        // User trends (last 30 days)
        const recentUsers = await (0, db_js_1.query)('SELECT createdAt FROM users WHERE createdAt >= ?', [thirtyDaysStr]);
        const userTrends = {};
        for (const u of recentUsers) {
            const d = (u.createdAt instanceof Date ? u.createdAt.toISOString() : String(u.createdAt)).split('T')[0];
            userTrends[d] = (userTrends[d] || 0) + 1;
        }
        const userTrendsArray = Object.entries(userTrends).map(([date, count]) => ({ date, count })).sort((a, b) => a.date.localeCompare(b.date));
        // Enrollment trends (last 30 days)
        const recentEnrollments = await (0, db_js_1.query)(`SELECT e.enrolledAt, c.price FROM enrollments e JOIN courses c ON e.courseId = c.id WHERE e.enrolledAt >= ?`, [thirtyDaysStr]);
        const enrollmentTrends = {};
        const revenueTrends = {};
        for (const e of recentEnrollments) {
            const d = (e.enrolledAt instanceof Date ? e.enrolledAt.toISOString() : String(e.enrolledAt)).split('T')[0];
            enrollmentTrends[d] = (enrollmentTrends[d] || 0) + 1;
            revenueTrends[d] = (revenueTrends[d] || 0) + (e.price || 0);
        }
        const enrollmentTrendsArray = Object.entries(enrollmentTrends).map(([date, count]) => ({ date, count })).sort((a, b) => a.date.localeCompare(b.date));
        const revenueTrendsArray = Object.entries(revenueTrends).map(([date, amount]) => ({ date, amount })).sort((a, b) => a.date.localeCompare(b.date));
        // Top courses
        const topCourses = await (0, db_js_1.query)(`SELECT c.id, c.title, c.price, COUNT(e.id) as enrollCount
       FROM courses c LEFT JOIN enrollments e ON e.courseId = c.id
       GROUP BY c.id ORDER BY enrollCount DESC LIMIT 10`);
        const topCoursesIds = topCourses.map(c => c.id);
        let ratingsByCourse = new Map();
        if (topCoursesIds.length > 0) {
            const rp = (0, db_js_1.inPlaceholders)(topCoursesIds);
            const ratings = await (0, db_js_1.query)(`SELECT courseId, AVG(rating) as avg, COUNT(*) as cnt FROM reviews WHERE courseId IN (${rp}) GROUP BY courseId`, topCoursesIds);
            for (const r of ratings)
                ratingsByCourse.set(r.courseId, { sum: Number(r.avg), cnt: Number(r.cnt) });
        }
        const topCoursesWithStats = topCourses.map(c => ({
            id: c.id, title: c.title,
            enrollments: Number(c.enrollCount),
            revenue: c.price * Number(c.enrollCount),
            rating: ratingsByCourse.has(c.id) ? Math.round(ratingsByCourse.get(c.id).sum * 10) / 10 : null,
        }));
        // User distribution by role
        const roleRows = await (0, db_js_1.query)('SELECT role, COUNT(*) as cnt FROM users GROUP BY role');
        const userDistribution = {};
        for (const r of roleRows)
            userDistribution[r.role] = Number(r.cnt);
        // Category distribution
        const catRows = await (0, db_js_1.query)('SELECT category, COUNT(*) as cnt FROM courses WHERE category IS NOT NULL GROUP BY category');
        const categoryDistribution = catRows.map(r => ({ category: r.category, count: Number(r.cnt) }));
        // Progress distribution buckets
        const progressBuckets = { '0-25': 0, '25-50': 0, '50-75': 0, '75-100': 0, 'completed': 0 };
        // Use the already-computed enrollment data
        if (enrollmentsForCompletion.length > 0) {
            const courseIds = [...new Set(enrollmentsForCompletion.map(e => e.courseId))];
            const cp2 = (0, db_js_1.inPlaceholders)(courseIds);
            const lessonCounts2 = await (0, db_js_1.query)(`SELECT m.courseId, COUNT(l.id) as cnt FROM modules m JOIN lessons l ON l.moduleId = m.id WHERE m.courseId IN (${cp2}) GROUP BY m.courseId`, courseIds);
            const totalLessonsMap2 = new Map(lessonCounts2.map(r => [r.courseId, Number(r.cnt)]));
            const eIds2 = enrollmentsForCompletion.map(e => e.enrollmentId);
            const ep2 = (0, db_js_1.inPlaceholders)(eIds2);
            const completedCounts2 = await (0, db_js_1.query)(`SELECT enrollmentId, COUNT(*) as cnt FROM lesson_progress WHERE enrollmentId IN (${ep2}) AND completedAt IS NOT NULL GROUP BY enrollmentId`, eIds2);
            const completedMap2 = new Map(completedCounts2.map(r => [r.enrollmentId, Number(r.cnt)]));
            for (const enr of enrollmentsForCompletion) {
                const tl = totalLessonsMap2.get(enr.courseId) ?? 0;
                if (tl === 0)
                    continue;
                const cl = completedMap2.get(enr.enrollmentId) ?? 0;
                const pct = (cl / tl) * 100;
                if (pct >= 100)
                    progressBuckets['completed']++;
                else if (pct >= 75)
                    progressBuckets['75-100']++;
                else if (pct >= 50)
                    progressBuckets['50-75']++;
                else if (pct >= 25)
                    progressBuckets['25-50']++;
                else
                    progressBuckets['0-25']++;
            }
        }
        // Top learners
        const topLearners = await (0, db_js_1.query)(`SELECT e.id as enrollmentId, u.email, u.name, c.title as course,
              (SELECT MAX(lp2.lastWatchedAt) FROM lesson_progress lp2 WHERE lp2.enrollmentId = e.id) as lastActive
       FROM enrollments e
       JOIN users u ON e.userId = u.id
       JOIN courses c ON e.courseId = c.id
       ORDER BY e.enrolledAt DESC LIMIT 10`);
        const topLearnersData = topLearners.map(e => ({
            email: e.email, name: e.name,
            lastActive: e.lastActive ? (e.lastActive instanceof Date ? e.lastActive.toISOString() : e.lastActive) : null,
            course: e.course, progress: 0,
        }));
        res.json({
            analytics: {
                overview: {
                    totalUsers, totalCourses, totalEnrollments,
                    totalRevenue: Math.round(totalRevenue * 100) / 100,
                    activeUsers, completionRate: Math.round(completionRate * 10) / 10,
                },
                trends: { users: userTrendsArray, enrollments: enrollmentTrendsArray, revenue: revenueTrendsArray },
                topCourses: topCoursesWithStats,
                userDistribution, categoryDistribution, progressBuckets,
                topLearners: topLearnersData,
            },
        });
    }
    catch (error) {
        console.error('Get analytics error:', error);
        res.status(500).json({ error: 'Failed to get analytics' });
    }
});
// GET /analytics/creator-stats
router.get('/creator-stats', auth_js_1.authenticate, async (req, res) => {
    try {
        const userId = req.user.id;
        const [totalRow, publishedRow, enrollData, reviewsData] = await Promise.all([
            (0, db_js_1.queryOne)('SELECT COUNT(*) as cnt FROM courses WHERE creatorId = ?', [userId]),
            (0, db_js_1.queryOne)('SELECT COUNT(*) as cnt FROM courses WHERE creatorId = ? AND status = ?', [userId, 'PUBLISHED']),
            (0, db_js_1.query)(`SELECT c.price, COUNT(e.id) as enrollCount
         FROM courses c LEFT JOIN enrollments e ON e.courseId = c.id
         WHERE c.creatorId = ? GROUP BY c.id`, [userId]),
            (0, db_js_1.query)('SELECT r.rating FROM reviews r JOIN courses c ON r.courseId = c.id WHERE c.creatorId = ?', [userId]),
        ]);
        const totalEnrollments = enrollData.reduce((s, c) => s + Number(c.enrollCount), 0);
        const totalRevenue = enrollData.reduce((s, c) => s + c.price * Number(c.enrollCount), 0);
        const totalReviews = reviewsData.length;
        const avgRating = totalReviews > 0
            ? (reviewsData.reduce((s, r) => s + r.rating, 0) / totalReviews).toFixed(1)
            : '0.0';
        res.json({
            totalCourses: Number(totalRow?.cnt ?? 0),
            publishedCourses: Number(publishedRow?.cnt ?? 0),
            totalEnrollments,
            totalRevenue: Math.round(totalRevenue * 100) / 100,
            totalReviews,
            avgRating,
        });
    }
    catch (error) {
        console.error('Get creator stats error:', error);
        res.status(500).json({ error: 'Failed to get creator stats' });
    }
});
// GET /analytics/learner-stats
router.get('/learner-stats', auth_js_1.authenticate, async (req, res) => {
    try {
        const userId = req.user.id;
        const enrollments = await (0, db_js_1.query)(`SELECT e.id, e.userId, e.courseId, e.enrolledAt, c.id as c_id, c.title, c.coverImage
       FROM enrollments e JOIN courses c ON e.courseId = c.id
       WHERE e.userId = ?`, [userId]);
        let totalCourses = enrollments.length;
        let completedCourses = 0;
        let inProgressCourses = 0;
        let totalLessonsCompleted = 0;
        let totalWatchTime = 0;
        const formattedEnrollments = [];
        for (const enr of enrollments) {
            // Total lessons
            const lessonCountRow = await (0, db_js_1.queryOne)('SELECT COUNT(*) as cnt FROM modules m JOIN lessons l ON l.moduleId = m.id WHERE m.courseId = ?', [enr.courseId]);
            const totalLessonsInCourse = Number(lessonCountRow?.cnt ?? 0);
            // Progress
            const progressRows = await (0, db_js_1.query)('SELECT progressPercent, completedAt FROM lesson_progress WHERE enrollmentId = ?', [enr.id]);
            const completedLessons = progressRows.filter(lp => lp.completedAt != null).length;
            totalLessonsCompleted += completedLessons;
            progressRows.forEach(lp => { totalWatchTime += lp.lastWatchedTimestamp ?? 0; });
            if (totalLessonsInCourse > 0 && completedLessons === totalLessonsInCourse) {
                completedCourses++;
            }
            else if (completedLessons > 0) {
                inProgressCourses++;
            }
            formattedEnrollments.push({
                id: enr.id, userId: enr.userId, courseId: enr.courseId,
                enrolledAt: enr.enrolledAt instanceof Date ? enr.enrolledAt.toISOString() : enr.enrolledAt,
                course: { id: enr.c_id, title: enr.title, thumbnail: enr.coverImage },
                lessonProgress: progressRows.map(lp => ({
                    progressPercent: lp.progressPercent,
                    completedAt: lp.completedAt ? (lp.completedAt instanceof Date ? lp.completedAt.toISOString() : lp.completedAt) : null,
                })),
            });
        }
        res.json({
            totalCourses, completedCourses, inProgressCourses, totalLessonsCompleted,
            totalWatchHours: Math.round((totalWatchTime / 3600) * 10) / 10,
            enrollments: formattedEnrollments,
        });
    }
    catch (error) {
        console.error('Get learner stats error:', error);
        res.status(500).json({ error: 'Failed to get learner stats' });
    }
});
exports.default = router;
//# sourceMappingURL=analytics.js.map